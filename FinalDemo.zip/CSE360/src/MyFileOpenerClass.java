import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.swing.JFileChooser;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sakshamsaraswat
 */
public class MyFileOpenerClass {
    
    JFileChooser file_chooser = new JFileChooser();
    StringBuilder sb = new StringBuilder();
    
    int characters = 0, words = 0, lines = 0;
    int cnt = 0;
    
    public void pick_me() throws FileNotFoundException, IOException
    {
      if(file_chooser.showOpenDialog(null)==JFileChooser.APPROVE_OPTION)  
      {
        File file = file_chooser.getSelectedFile();
        Scanner input = new Scanner(file);
 
        while(input.hasNext())
        {
            sb.append(input.nextLine());
            sb.append("\n");            
        }
        
        
        input.close(); 
        //writer.close();
          
      } 
      else
      {
          
         sb.append("No file was selected");
          
      } 
    }
   public  String file() {
	   String hah = file_chooser.getSelectedFile().toString();
	   return hah;
   }
    
}